
public class Main {

	public static void main(String[] args) {
		TicketSystem t1 = new TicketSystem();
		
		MyThread th1 = new MyThread(t1,"A");
		MyThread th2 = new MyThread(t1,"X");
		MyThread th3 = new MyThread(t1,"Ρ");
		th3.start();
		th1.start();
		th2.start();
		
		
		try {
			th1.join();
			th2.join();
			th3.join();
			System.out.println("===== END OF THE DAY ======");
			System.err.println("The available tickets is: "+ t1.getAvailableTickets());
		}
		catch(InterruptedException e){
		}
	}

}

class MyThread extends Thread{
	
	private TicketSystem ticketSystem;
	private String name;
	
	public MyThread(TicketSystem ts, String name) {
		this.ticketSystem = ts;
		 this.name= name;
	}
	
	public void run() {
		for(int i=0;i<4; i++) {
			ticketSystem.bookTicket(name);
			
			try {
	            Thread.sleep(100); // Κοιμάται για 100 milliseconds
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
		}
	}
}
