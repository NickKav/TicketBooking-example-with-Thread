import java.awt.print.Printable;

public class TicketSystem {

	private int availableTickets = 16;
	//private String name;
	
	public TicketSystem() {
		
	}
	
	public synchronized void bookTicket(String name) {
		if(availableTickets > 0) {
			System.out.println("Ο Πελάτης "+ name +" αγόρασε το εισιτήριο "+ availableTickets);
			availableTickets --;
		}else {
			System.out.println("Δεν υπάρχουν αλλα διαθέσιμα εισιτήρια.");
		}
	}

	public int getAvailableTickets() {
		return availableTickets;
	}


	
	
	
}
